# Web-Projekte

Hier kommt alles rein, was für Webseiten und Web-Apps relevant ist.

## Beispiele:
- HTML/CSS/JS
- React, Vue, Svelte, etc.
- Web-spezifische Assets und Konfigurationen

**Startpunkte und Beispielcode folgen bei Bedarf!**