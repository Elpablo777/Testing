# Strukturübersicht – Basis/Testing Repo v1.1.0

## Frameworks
- /frameworks/react/         – React-Start (JS & TS)
- /frameworks/flutter/       – Flutter-Starter
- /frameworks/django/        – Django-Starter
- /frameworks/express/       – Express-Starter
- /frameworks/pwa/           – PWA-Manifest, Service Worker

## Protokolle & Agenten
- /a2a-mcp/                  – Agent-to-Agent, Model Context Protocol (Windsurf, Cline, etc.)

*(Restliche Struktur: siehe vorherige Übersicht)*