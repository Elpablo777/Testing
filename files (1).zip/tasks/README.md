# ToDos & Fortschritt

## Offene Aufgaben
- [ ] MCP/python-sdk und MCP/typescript-sdk als optionale Submodule einbinden
- [ ] Eigene Beispiel-Clients (Python/TypeScript) für MCP/A2A bauen
- [ ] Integrationsbeispiele für Windsurf/Cline vertiefen
- [ ] Feedback einholen & Repo weiter verbessern

## Erledigt (v1.2.0)
- MCP/A2A sauber integriert & dokumentiert
- Framework-Starter aktualisiert
- Struktur- und README-Updates