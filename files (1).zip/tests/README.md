# Test-Verzeichnis

Hier sollten künftig automatisierte Tests abgelegt werden.