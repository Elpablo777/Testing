# Sicherheitsrichtlinien

Bitte melde Sicherheitslücken ausschließlich vertraulich per E-Mail oder als privates GitHub-Issue.
Wir nehmen Sicherheit ernst und reagieren zeitnah auf alle Meldungen.

## Kontakt
- Maintainer: @Elpablo777
- Alternativ: GitHub-Issue mit [security] im Titel