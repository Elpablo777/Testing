# Pull Request

**Kurzbeschreibung der Änderung:**

Fixes #

## Typ der Änderung
- [ ] Bugfix
- [ ] Feature
- [ ] Refactoring
- [ ] Dokumentation

## Checkliste
- [ ] Funktioniert lokal/Tests laufen
- [ ] Doku aktualisiert (falls nötig)
- [ ] Code-Stil eingehalten