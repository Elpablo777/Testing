# Mobile Apps

Hier kommt alles rein, was für mobile Apps genutzt wird.

## Beispiele:
- Flutter-Projekte (plattformübergreifend)
- React Native (iOS/Android)
- Native Android/iOS (Platzhalter)

**Startpunkte und Beispielcode folgen bei Bedarf!**