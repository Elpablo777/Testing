# Beitrag zum Projekt "Testing"

Danke für dein Interesse an einem Beitrag!

## Wie kann ich beitragen?
- Fehler oder Vorschläge als Issue melden.
- Änderungen als Pull Request einreichen.
- Beschreibe deine Änderung klar und präzise.

## Code-Stil
- Halte dich an gängige Formatierungsregeln.
- Schreibe sauberen, nachvollziehbaren Code.

## Fragen?
Einfach ein Issue eröffnen!