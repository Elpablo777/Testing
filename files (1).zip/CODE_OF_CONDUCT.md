# Verhaltenskodex

Wir erwarten respektvollen, freundlichen Umgang. Diskriminierung, Belästigung oder Beleidigungen werden nicht toleriert.

## Verstöße melden
Bitte direkt per Issue oder privat an den Maintainer.

Danke für deinen Beitrag zu einer offenen, positiven Community!