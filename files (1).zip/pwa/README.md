# Progressive Web App (PWA)

Hier können PWA-spezifische Dateien, Manifeste, Service Worker etc. abgelegt werden.

**Startpunkte und Beispielcode folgen bei Bedarf!**