# Ruby

## Kurzbeschreibung
Ruby ist bekannt für seine Eleganz und Lesbarkeit, beliebt im Web (Ruby on Rails).

## Minimalbeispiel
```ruby
puts "Hello, World!"
```

## Typische Startdateien
- `main.rb`
- `Gemfile`