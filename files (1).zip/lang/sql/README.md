# SQL

## Kurzbeschreibung
SQL ist die Standardsprache für Datenbanken.

## Minimalbeispiel
```sql
SELECT 'Hello, World!';
```

## Typische Startdateien
- `script.sql`