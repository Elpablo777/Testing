# Shell (Bash)

## Kurzbeschreibung
Shell-Skripte automatisieren Aufgaben auf Linux/Mac/Unix-Systemen.

## Minimalbeispiel
```sh
echo "Hello, World!"
```

## Typische Startdateien
- `script.sh`