# PHP

## Kurzbeschreibung
PHP wird oft für Webserver-Backends verwendet, läuft auf fast jedem Webserver.

## Minimalbeispiel
```php
<?php
echo "Hello, World!";
?>
```

## Typische Startdateien
- `index.php`
- `composer.json`