# Rust

## Kurzbeschreibung
Rust ist eine moderne Sprache für sichere und performante System- und Webentwicklung.

## Minimalbeispiel
```rust
fn main() {
    println!("Hello, World!");
}
```

## Typische Startdateien
- `main.rs`
- `Cargo.toml`