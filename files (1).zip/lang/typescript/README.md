# TypeScript

## Kurzbeschreibung
TypeScript ist ein typisiertes Superset von JavaScript – für große, sichere Webanwendungen.

## Minimalbeispiel
```typescript
console.log("Hello, World!");
```

## Typische Startdateien
- `index.ts`
- `tsconfig.json`