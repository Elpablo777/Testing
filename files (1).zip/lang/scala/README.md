# Scala

## Kurzbeschreibung
Scala verbindet objektorientierte und funktionale Programmierung, läuft auf der JVM.

## Minimalbeispiel
```scala
object Main extends App {
    println("Hello, World!")
}
```

## Typische Startdateien
- `Main.scala`
- `build.sbt`