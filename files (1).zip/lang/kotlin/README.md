# Kotlin

## Kurzbeschreibung
Kotlin ist eine moderne Sprache für Android, Server und Web, interoperabel mit Java.

## Minimalbeispiel
```kotlin
fun main() {
    println("Hello, World!")
}
```

## Typische Startdateien
- `Main.kt`
- `build.gradle.kts`