# PowerShell

## Kurzbeschreibung
PowerShell ist eine mächtige Skriptsprache von Microsoft für Systemadministration.

## Minimalbeispiel
```powershell
Write-Output "Hello, World!"
```

## Typische Startdateien
- `script.ps1`