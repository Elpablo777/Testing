# JSON

## Kurzbeschreibung
JSON ist ein plattformübergreifendes Datenformat für Konfiguration, API, Speicherung.

## Minimalbeispiel
```json
{
  "message": "Hello, World!"
}
```

## Typische Startdateien
- `config.json`
- `data.json`