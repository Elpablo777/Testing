# Dart (Flutter)

## Kurzbeschreibung
Dart ist die Programmiersprache hinter Flutter, ideal für plattformübergreifende Apps (iOS, Android, Web, Desktop).

## Minimalbeispiel
```dart
void main() {
  print('Hello, World!');
}
```

## Typische Startdateien
- `main.dart`
- `pubspec.yaml`