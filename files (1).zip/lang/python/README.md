# Python

## Kurzbeschreibung
Python ist eine universelle, leicht zu erlernende Sprache für Datenanalyse, KI, Webentwicklung, Automatisierung und vieles mehr.

## Minimalbeispiel
```python
print("Hello, World!")
```

## Typische Startdateien
- `main.py`
- `requirements.txt`