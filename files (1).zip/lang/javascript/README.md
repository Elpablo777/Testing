# JavaScript

## Kurzbeschreibung
JavaScript ist die Sprache des Webs, für Frontend, Backend (Node.js) und viele Frameworks.

## Minimalbeispiel
```javascript
console.log("Hello, World!");
```

## Typische Startdateien
- `index.js`
- `package.json`