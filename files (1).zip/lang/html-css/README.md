# HTML & CSS

## Kurzbeschreibung
HTML und CSS sind die Kerntechnologien für Webseiten, Layout und Design.

## Minimalbeispiel (HTML)
```html
<!DOCTYPE html>
<html lang="de">
<head><meta charset="UTF-8"><title>Hello</title></head>
<body>Hello, World!</body>
</html>
```

## Typische Startdateien
- `index.html`
- `styles.css`