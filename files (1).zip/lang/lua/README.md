# Lua

## Kurzbeschreibung
Lua ist eine leichte, eingebettete Skriptsprache – beliebt in Games und Automatisierung.

## Minimalbeispiel
```lua
print("Hello, World!")
```

## Typische Startdateien
- `main.lua`