# Prompts & LLM-Anweisungen

Hier werden Systemprompts, LLM-Kontexte und Anweisungen zentral abgelegt.