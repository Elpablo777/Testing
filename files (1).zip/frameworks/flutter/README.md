# Flutter Starter

Plattformübergreifender App-Startpunkt (Android, iOS, Web, Desktop).  
Install: `flutter pub get`  
Start: `flutter run`

## Dateien
- pubspec.yaml
- lib/main.dart

## Letztes Update: v1.2.0 – geprüft, funktionsbereit