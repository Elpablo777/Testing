# Django Starter

Backend-Webframework für Python.  
Install: `pip install -r requirements.txt`  
Start: `python manage.py runserver`

## Dateien
- requirements.txt
- manage.py (Platzhalter)

## Letztes Update: v1.2.0 – geprüft, funktionsbereit