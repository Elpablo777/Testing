# Express Starter

Node.js Backend-Framework.  
Install: `npm install`  
Start: `node app.js`

## Dateien
- package.json
- app.js

## Letztes Update: v1.2.0 – geprüft, funktionsbereit