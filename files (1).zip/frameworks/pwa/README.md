# PWA Starter

Progressive Web App Grundstruktur  
- manifest.json
- service-worker.js

Kann in jedes Web-Projekt integriert werden, um Offline-Fähigkeit und App-Feeling zu erreichen.

## Letztes Update: v1.2.0 – geprüft, funktionsbereit