# React Starter

Beispiel für React (JavaScript & TypeScript).  
Install: `npm install`  
Start: `npm start`  
Typische Nutzung für Web-Apps, auch als Basis für KI-Frontend.

## Dateien
- package.json
- src/App.js
- src/App.tsx
- public/index.html

## Letztes Update: v1.2.0 – geprüft, funktionsbereit